//@ts-nocheck
sap.ui.define([
    "./BaseController"],
    /**
     * @param {typeof sap.ui.core.mvc.Controller} BaseController
     */
    function (BaseController) {
        "use strict";

        return BaseController.extend("zdashboard.controller.Home", {})
    });
sap.ui.define(["./BaseController"],function(e){"use strict";return e.extend("zdashboard.controller.Home",{})});
//# sourceMappingURL=Home.controller.js.map